from django.apps import AppConfig


class CheckConfig(AppConfig):
    name = 'check'
